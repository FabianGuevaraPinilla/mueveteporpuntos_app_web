import React, {useState} from 'react'
import { Form } from 'react-bootstrap'

import "./FormEventoNuevo.scss"

export default function FormEventoNuevo(props) {

    //const [tipoEventos, categoriaEventos, sucursales] = props;
    // const [tipos, setTipos] = useState(props.tipoEventos)

    // const [modeloEvento, setmodeloEvento] = useState(null)

    return (
        <div>
             {/* //Formulario de nuevo evento */}
             <h3>Formulario de nuevo evento</h3>
             <h4>aqui el formulario {"nada"}</h4>
            <div>
            {/* {props.tipoEventos.map((tipo)=>{
                      <p>{tipo}</p>
             })} */}
            </div>
 
        </div>
    )
}
