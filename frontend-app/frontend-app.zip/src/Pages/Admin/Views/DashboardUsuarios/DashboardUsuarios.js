import React, { Component } from 'react'

export default class DashboardUsuarios extends Component {
    render() {
        return (
            <div>
                <h1>DASHBOARD usuario</h1>
            </div>
        )
    }
}
