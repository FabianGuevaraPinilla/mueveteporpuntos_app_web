
import React, { Component } from 'react'

export default class DashboardMain extends Component {
    render() {
        return (
            <div>
                <p>Resumen del dashboard</p>
            </div>
        )
    }
}

