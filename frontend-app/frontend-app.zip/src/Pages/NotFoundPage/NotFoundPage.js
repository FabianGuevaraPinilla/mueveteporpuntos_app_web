import React from 'react'

export default function NotFoundPage() {
    return (
        <div>
            <h1 style={{ marginTop: 300 }}>404
                <br />
                Página no encontrada
            </h1>
        </div>
    )
}
