module.exports = {
    HOST_API: process.env.REACT_APP_HOST_API || 'https://mueveteporpuntosapp.herokuapp.com/api',
    HOST: process.env.REACT_APP_HOST_BACKEND  || 'https://mueveteporpuntosapp.herokuapp.com',
}